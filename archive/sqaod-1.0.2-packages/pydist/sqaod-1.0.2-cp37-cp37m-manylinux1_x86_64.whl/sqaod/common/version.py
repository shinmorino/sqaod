sqaodpy_version = '1.0.2'
sqaodc_version = 10002

libsqaodc_name = 'libsqaodc.so.1'
libsqaodc_cuda_name = 'libsqaodc_cuda.so.1'
