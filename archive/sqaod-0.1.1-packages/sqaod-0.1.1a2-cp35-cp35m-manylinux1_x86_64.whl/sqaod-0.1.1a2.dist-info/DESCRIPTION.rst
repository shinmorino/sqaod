Sqaod is a collection of sovlers for simulated quantum annealing.  Solvers are acelerated by using OpenMP on multi-core CPUs and by using CUDA on NVIDIA GPUs.Please visit sqaod website for details, https://github.com/shinmorino/sqaod/.


