#pragma once

/* build configuration */

/* BLAS */
/* #define SQAODC_WITH_BLAS */

/* CUDA */
#define SQAODC_CUDA_ENABLED

